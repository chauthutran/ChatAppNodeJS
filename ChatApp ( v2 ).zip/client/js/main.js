const chatForm = document.getElementById('chat-form');
const chatMessages = document.querySelector('.chat-messages');
const roomName = document.getElementById('room-name');
const userList = document.getElementById('users');

let socket;
let isConnectServer = true;
let queueMsgList = [];

// Get username and room from URL
const { username, room } = Qs.parse(location.search, {
	ignoreQueryPrefix: true,
});


try
{
	


console.log("username: " + username );
console.log("room: " + room );

socket = io("http://localhost:3000", {
	reconnectionDelayMax: 1000,
	withCredentials: true,
	extraHeaders: {
		"Access-Control-Allow-Origin": "origin-list"
	},
	// upgrade: false,
    // reconnection: false,
    // rejectUnauthorized: false
});

socket.on('connect_error', function() {
    console.log('Failed to connect to server');
	isConnectServer = false;
});

socket.on('connect', function () {
	alert('Socket is connected.');
	isConnectServer = true;

	// Send the queue message if there is any message unsent

	for( i=queueMsgList.length - 1; i>=0; i-- )
	{
		// Emit message to server
		socket.emit('chatMessage', queueMsgList[i]);
	}

});

socket.on('disconnect', function () {
	alert('Socket is disconnected.');
});



// Join chatroom
socket.emit('joinRoom', { username, room });

// Get room and users
socket.on('roomUsers', ({ room, users }) => {
	console.log("joined in room ");
	outputRoomName(room);
	outputUsers(users);
});


// Message from server
socket.on('message', (message) => {
	console.log(message);

	let messageTag = $('.chat-messages').find("div#" + message.id);
	if( messageTag.length > 0 )
	{
		messageTag.removeClass("offline");
		removeFromArray( queueMsgList, "id", message.id );
	}
	else
	{
		outputMessage(message);
	}
	

	// Scroll down
	chatMessages.scrollTop = chatMessages.scrollHeight;
});

}
catch( ex )
{
	console.log(ex);
}


// Message submit
chatForm.addEventListener('submit', (e) => {
	e.preventDefault();

	// Get message text
	let msg = e.target.elements.msg.value;
	msg = msg.trim();
	if (!msg) {
		return false;
	}

	if( isConnectServer )
	{
		// Emit message to server
		socket.emit('chatMessage', formatMessage(username, msg) );
	}
	else
	{
		const data = formatMessage( username, msg );
		queueMsgList.push( data );
		outputMessage( data );
	}

	// Clear input
	e.target.elements.msg.value = '';
	e.target.elements.msg.focus();
});

	// Output message to DOM
	function outputMessage(message) {
		const div = document.createElement('div');
		div.setAttribute("id", message.id);
		div.classList.add('message');
		if( !isConnectServer )
		{ 
			div.classList.add('offline');
		}
		const p = document.createElement('p');
		p.classList.add('meta');
		p.innerText = message.username;
		p.innerHTML += `<span>${message.time}</span>`;
		div.appendChild(p);
		const para = document.createElement('p');
		para.classList.add('text');
		para.innerText = message.text;
		div.appendChild(para);
		document.querySelector('.chat-messages').appendChild(div);
	}

	// Add room name to DOM
	function outputRoomName(room) {
		roomName.innerText = room;
	}

	// Add users to DOM
	function outputUsers(users) {
		userList.innerHTML = '';
		users.forEach((user) => {
			const li = document.createElement('li');
			li.innerText = user.username;
			userList.appendChild(li);
		});
	}

	//Prompt the user before leave chat room
	document.getElementById('leave-btn').addEventListener('click', () => {
		const leaveRoom = confirm('Are you sure you want to leave the chatroom?');
		if (leaveRoom) {
			window.location = 'index.html';
		} else {
		}
});
